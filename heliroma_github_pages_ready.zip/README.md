# HELIROMA — Web App (GitHub Pages)

Este pacote está pronto para ser publicado no **GitHub Pages**.

## Publicar no GitHub Pages (passo a passo)

1. Crie um repositório novo no GitHub (ex.: `heliroma-app`).
2. Faça upload destes ficheiros **na raiz do repositório** (root):
   - `index.html`
   - `manifest.webmanifest`
   - `sw.js`
   - pasta `icons/`
   - `.nojekyll`

3. No GitHub, vá em **Settings → Pages**:
   - **Source**: `Deploy from a branch`
   - **Branch**: `main`
   - **Folder**: `/ (root)`
4. Guarde. O GitHub vai gerar o link do site (ex.: `https://<user>.github.io/<repo>/`).

## Dicas

- Para garantir que funciona também quando o repositório está num **sub-caminho** (`/.../<repo>/`), todos os caminhos no app usam `./`.
- O `sw.js` ativa cache offline (PWA). Para forçar atualização no telemóvel, faça “hard refresh” ou limpe cache do site.

